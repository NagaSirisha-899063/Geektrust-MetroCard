package com.example.geektrust.constant;

public enum Station 
{
    CENTRAL,
    AIRPORT
}
