package com.example.geektrust.constant;

public class Common 
{
    public static final String SPACE = " ";
    public static final int ZERO = 0;
    public static final int TWO = 2;
    public static final int THREE = 3;
    public static final float PERCENTAGE = 0.02f;
}
