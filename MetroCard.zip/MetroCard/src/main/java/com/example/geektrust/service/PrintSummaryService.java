package com.example.geektrust.service;

public interface PrintSummaryService 
{
	//prints the summary in desired format after all the operations
    void printSummary();
}
