package com.example.geektrust;

import org.junit.jupiter.api.Test;

public class MainTest 
{
    @Test
    public void ContextLoads() 
    {
    }
}