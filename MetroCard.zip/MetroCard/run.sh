#!/bin/bash

//Build the jar using this command in the project file path
mvn clean install 

//Run the jar file located in the target folder along with the input file path
java -jar target\geektrust.jar sample_input\input1.txt
java -jar target\geektrust.jar sample_input\input2.txt